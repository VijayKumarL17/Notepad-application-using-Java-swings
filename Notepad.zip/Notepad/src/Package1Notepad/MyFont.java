package Package1Notepad;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Frame;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import javax.swing.SpinnerNumberModel;
import javax.swing.event.ChangeListener;
import javax.swing.event.ChangeEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class MyFont extends JFrame implements ActionListener {
    
	private JPanel contentPane;
    private JComboBox style,family;
    private JButton ok,cancel;
    static JSpinner size;
/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					
					MyFont frame = new MyFont();
					frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
		});
	}

	/**
	 * Create the frame.
	 */
	
	public MyFont() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				dispose();
			}
		});
				
		setTitle("Font");
		setIconImage(Toolkit.getDefaultToolkit().getImage(MyFont.class.getResource("/Images/MyNotepad.png")));

		setBounds(100, 100, 784, 331);

		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Font:");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblNewLabel.setBounds(35, 30, 86, 28);
		contentPane.add(lblNewLabel);
		
		JLabel lblFontSize = new JLabel("Font size:");
		lblFontSize.setHorizontalAlignment(SwingConstants.CENTER);
		lblFontSize.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblFontSize.setBounds(620, 30, 86, 28);
		contentPane.add(lblFontSize);
		
		JLabel lblFontStyle = new JLabel("Font style:");
		lblFontStyle.setHorizontalAlignment(SwingConstants.CENTER);
		lblFontStyle.setFont(new Font("Times New Roman", Font.PLAIN, 15));
		lblFontStyle.setBounds(316, 36, 86, 28);
		contentPane.add(lblFontStyle);
        String[] fonts=GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
		
        family=new JComboBox(fonts);
       
        family.setSelectedIndex(3);
         family.setBounds(35, 94, 134, 22);
		contentPane.add(family);
         size = new JSpinner();
		
		 size.setModel(new SpinnerNumberModel(24, 12, 60, 2));
		 size.setToolTipText("0");
		size.setBounds(620, 94, 96, 22);
		contentPane.add(size);
		size.setValue(24);
		 
		contentPane.add(family);
		style = new JComboBox();
		
		style.setBounds(310, 94, 106, 22);
		contentPane.add(style);
		String[] styles = { "Plain","Bold","Italic" };
		for(int i=0;i<3;i++) {
			style.addItem(styles[i]);
		}
		
		 ok = new JButton("OK");
		ok.setBounds(474, 237, 106, 34);
		contentPane.add(ok);
		ok.addActionListener(this);
        cancel = new JButton("Cancel");
		cancel.setBounds(610, 237, 106, 34);
		contentPane.add(cancel);
		cancel.addActionListener(this);
		
		
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// TODO Auto-generated method stub
		if(arg0.getSource()==ok) {

//	        		JOptionPane.showMessageDialog(null, family.getSelectedItem()+" "+style.getSelectedItem()+" "+size.getValue());
//	        		System.out.println("Calling");
			        if(style.getSelectedItem()=="Bold") {
			        	Frame1.textAreaNotepad.setFont(new Font((String)family.getSelectedItem(),Font.BOLD,(int)size.getValue()));
			        }
			        else if(style.getSelectedItem()=="Italic") {
			        	Frame1.textAreaNotepad.setFont(new Font((String)family.getSelectedItem(),Font.ITALIC,(int)size.getValue()));
			        }
			      
			        else {
        		    Frame1.textAreaNotepad.setFont(new Font((String)family.getSelectedItem(),Font.PLAIN,(int)size.getValue()));
	        		
	        		}
			        
			        dispose();
			
		}
		else {
			dispose();
		}
	}}
	

