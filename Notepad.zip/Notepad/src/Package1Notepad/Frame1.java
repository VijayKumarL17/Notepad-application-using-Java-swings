package Package1Notepad;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.KeyStroke;
import javax.swing.ScrollPaneConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JButton;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.print.PrinterException;

public class Frame1 extends JFrame implements ActionListener{

	private JPanel contentPane;
	private JMenu edit;
	static JTextArea textAreaNotepad;
	private String text;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Frame1 frame = new Frame1();;
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public Frame1() {
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				int response=JOptionPane.showConfirmDialog(null, "Do you want to exit?","Exit",JOptionPane.YES_NO_OPTION);

				if(response==JOptionPane.YES_OPTION)
					dispose();
				else {
					setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
				}

			}

		});

		setBackground(SystemColor.activeCaption);
		setIconImage(Toolkit.getDefaultToolkit().getImage(Frame1.class.getResource("/Images/MyNotepad.png")));
		setTitle("Untitled - My Notepad");
//        setMinimumSize(new Dimension(500,300));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 1400, 800);

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(SystemColor.menu);
		setJMenuBar(menuBar);

		JMenu file = new JMenu("File");

		menuBar.add(file);


		JMenuItem New = new JMenuItem("New");
		New.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,ActionEvent.CTRL_MASK));
		file.add(New);
		New.addActionListener((ActionListener) this);

		JMenuItem open = new JMenuItem("Open");
		open.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_O,ActionEvent.CTRL_MASK));
		file.add(open);
		open.addActionListener((ActionListener) this);

		JMenuItem save = new JMenuItem("Save");
		save.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_S,ActionEvent.CTRL_MASK));
		file.add(save);
		save.addActionListener((ActionListener) this);

		JMenuItem printText = new JMenuItem("Print");
		printText.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					textAreaNotepad.print();
				} catch (PrinterException e) {
					// TODO Auto-generated catch block
					JOptionPane.showMessageDialog(null, e.getMessage());
				}
			}
		});
		file.add(printText);
		printText.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_P,ActionEvent.CTRL_MASK));

		JMenuItem exit = new JMenuItem("Exit");
		exit.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_ESCAPE,0));
		file.add(exit);
		exit.addActionListener((ActionListener) this);

		edit = new JMenu("Edit");

		menuBar.add(edit);

		JMenuItem cut = new JMenuItem("Cut");
		cut.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_X,ActionEvent.CTRL_MASK));
		edit.add(cut);
		cut.addActionListener((ActionListener) this);

		JMenuItem copy = new JMenuItem("Copy");
		copy.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_C,ActionEvent.CTRL_MASK));
		edit.add(copy);
		copy.addActionListener((ActionListener) this);

		JMenuItem paste = new JMenuItem("Paste");
		paste.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_V,ActionEvent.CTRL_MASK));
		edit.add(paste);
		paste.addActionListener((ActionListener) this);

		JMenuItem selectAll = new JMenuItem("Select all");
		selectAll.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A,ActionEvent.CTRL_MASK));
		edit.add(selectAll);
		selectAll.addActionListener((ActionListener) this);

		JMenu format = new JMenu("Format");
		menuBar.add(format);

		JMenuItem font = new JMenuItem("Font");
		format.add(font);
		font.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ae) {
				new MyFont().setVisible(true);
			}
		});
		JMenu help = new JMenu("Help");
		menuBar.add(help);


		JMenuItem aboutUs = new JMenuItem("About");
		help.add(aboutUs);
		aboutUs.addActionListener((ActionListener) this);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new BorderLayout(0, 0));
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		contentPane.add(scrollPane);

		textAreaNotepad = new JTextArea();
		textAreaNotepad.setLineWrap(true);
		textAreaNotepad.setFont(new Font("Arial", Font.PLAIN, 20));
		scrollPane.setViewportView(textAreaNotepad);
		scrollPane.setBorder(BorderFactory.createEmptyBorder());
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
		if(e.getActionCommand().equals("New"))
			textAreaNotepad.setText("");
		else if(e.getActionCommand().equals("Open")) {

			JFileChooser fc=new JFileChooser();
			fc.setCurrentDirectory(new File("C:\\Users\\HP\\OneDrive\\Desktop"));
			
			FileNameExtensionFilter filter=new FileNameExtensionFilter("Text File","txt");
			fc.addChoosableFileFilter(filter);
			FileNameExtensionFilter filter1=new FileNameExtensionFilter("Java File","java");
			fc.addChoosableFileFilter(filter1);
			FileNameExtensionFilter filter2=new FileNameExtensionFilter("Python File","py");
			fc.addChoosableFileFilter(filter2);
			FileNameExtensionFilter filter3=new FileNameExtensionFilter("C File","c");
			fc.addChoosableFileFilter(filter3);
			FileNameExtensionFilter filter4=new FileNameExtensionFilter("C++ File","cpp");
			fc.addChoosableFileFilter(filter4);
			FileNameExtensionFilter filter5=new FileNameExtensionFilter("HTML File","html");
			fc.addChoosableFileFilter(filter5);
			FileNameExtensionFilter filter6=new FileNameExtensionFilter("CSS File",".css");
			fc.addChoosableFileFilter(filter6);
			int response=fc.showOpenDialog(null);
			if(response==fc.APPROVE_OPTION)
			{
				textAreaNotepad.setText(" ");
				File file;
				Scanner sc=null;
				file=new File(fc.getSelectedFile().getAbsolutePath());
				try {
					sc=new Scanner(file);
					if(file.isFile()) {


						while(sc.hasNextLine()) {
							String line=sc.nextLine()+"\n";
							textAreaNotepad.append(line);

						}
					}
				}
				catch(FileNotFoundException ex) {
					ex.printStackTrace();
				}
				finally {
					sc.close();
				}

				setTitle(file.getName()+" - My Notepad");
			}
		}
		else if(e.getActionCommand().equals("Save")) {
			JFileChooser fc=new JFileChooser();
			fc.setCurrentDirectory(new File("C:\\Users\\HP\\OneDrive\\Desktop"));
	
			int response=fc.showSaveDialog(null);
			if(response==JFileChooser.APPROVE_OPTION) {
				File file;
				PrintWriter fileOut=null;

				file=new File(fc.getSelectedFile().getAbsolutePath());
				try {
					fileOut=new PrintWriter(file);
					fileOut.println(textAreaNotepad.getText());
					setTitle(file.getName()+" - My Notepad");
				}
				catch(FileNotFoundException ex) {
					ex.printStackTrace();
				}
				finally {
					fileOut.close();
				}
			}
		}
		else if(e.getActionCommand().equals("Exit")) {
			int response=JOptionPane.showConfirmDialog(null, "Do you want to exit?","Exit",JOptionPane.YES_NO_OPTION,JOptionPane.QUESTION_MESSAGE);
			if(response==JOptionPane.YES_OPTION)
				System.exit(0);}
		else if(e.getActionCommand().equals("Cut")) {
			text=textAreaNotepad.getSelectedText();
			textAreaNotepad.replaceRange("", textAreaNotepad.getSelectionStart(), textAreaNotepad.getSelectionEnd());
		}else if(e.getActionCommand().equals("Copy")) {
			text=textAreaNotepad.getSelectedText();
		}else if(e.getActionCommand().equals("Paste")) {
			textAreaNotepad.insert(text, textAreaNotepad.getCaretPosition());
			//			textArea.append(text); Can also use this function to paste text

		}else if(e.getActionCommand().equals("Select all")) {
			textAreaNotepad.selectAll();
		}
		else if(e.getActionCommand().equals("About")) {
			new AboutUs().setVisible(true);;
		}
	}
}
