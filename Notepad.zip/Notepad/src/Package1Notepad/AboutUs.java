package Package1Notepad;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Toolkit;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;

public class AboutUs extends JFrame {
    private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AboutUs frame = new AboutUs();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public AboutUs() {
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowListener w) {
				dispose();
			}
			
		});
		setTitle("About My Notepad");
		setIconImage(Toolkit.getDefaultToolkit().getImage(AboutUs.class.getResource("/Images/MyNotepad.png")));
//		setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		setBounds(100, 100, 677, 528);
		setResizable(false);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
        ImageIcon ic=new ImageIcon(ClassLoader.getSystemResource("Images//notepad.png"));
		JLabel lblNewLabel = new JLabel(ic);
		lblNewLabel.setBounds(207, 13, 209, 215);
		contentPane.add(lblNewLabel);
        JLabel lblNewLabel_1 = new JLabel("<html>Application Name : My Notepad<br>Version : 1.0<br>About notepad : <br>Notepad is a word processing program, which allows changing of text in a computer file.It is a text editor, a very simple word processor. It has been a part of Microsoft Windows since 1985. The program has options such as changing the font, the font size, and the font style.<br>&copy Vijay Kumar L. All rights reserved.</html>");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Times New Roman", Font.PLAIN, 14));
		lblNewLabel_1.setBounds(37, 241, 591, 176);
		contentPane.add(lblNewLabel_1);
		JButton btnNewButton = new JButton("OK");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		btnNewButton.setBounds(242, 443, 97, 25);
		contentPane.add(btnNewButton);
	}
}
